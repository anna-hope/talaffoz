# talaffoz
Get the pronunciation of a word using a sequence-to-sequence neural network
